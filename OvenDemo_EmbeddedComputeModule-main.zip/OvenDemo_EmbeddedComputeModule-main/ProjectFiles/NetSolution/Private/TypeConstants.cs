using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace OvenDemo_EmbeddedComputeModule
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("OvenDemo_EmbeddedComputeModule");
        public static readonly NodeId MainPage = new NodeId(namespaceIndex, new Guid("81f873c2df7d55065426b9107a80596d"));
        public static readonly NodeId Phases = new NodeId(namespaceIndex, new Guid("b247cebf619a6438c19940eeb806f899"));
        public static readonly NodeId MainWindow = new NodeId(namespaceIndex, new Guid("d61a6bb0da58d2f94820c04b18e7e801"));
        public static readonly NodeId BasePanel = new NodeId(namespaceIndex, new Guid("4fb7f81b6dd60556c0470e584dbd90f7"));
        public static readonly NodeId Oven = new NodeId(namespaceIndex, new Guid("dbaca6e4b7cb6e4b797569c1ff8b8012"));
        public static readonly NodeId MainWindowWeb = new NodeId(namespaceIndex, new Guid("3fa35f7bdabe3c91aa0123039eb12153"));
        public static readonly NodeId Card = new NodeId(namespaceIndex, new Guid("78704b78222ebe881a0e3108a1112211"));
        public static readonly NodeId MainScaleLayout = new NodeId(namespaceIndex, new Guid("3ecc89fdf8d4b26e5b5794659865e065"));
        public static readonly NodeId Badge = new NodeId(namespaceIndex, new Guid("f6596ab428a62b650eee16ccfd887090"));
        public static readonly NodeId SinglePhasePanel = new NodeId(namespaceIndex, new Guid("1bc303e65dfecec71c9ff005ae61a312"));
        public static readonly NodeId NotificationPopup = new NodeId(namespaceIndex, new Guid("96ba3c9faea7d1a6f61c596b208b06fd"));
        public static readonly NodeId Recipes = new NodeId(namespaceIndex, new Guid("e9acad2f27612c7fa5b0859b6535933b"));
        public static readonly NodeId MainViewData = new NodeId(namespaceIndex, new Guid("37de321274886ab9e562997a9966ca18"));
        public static readonly NodeId MainViewAlarms = new NodeId(namespaceIndex, new Guid("4635f89fd25982d930145d5d90b2d433"));
        public static readonly NodeId MainViewSettings = new NodeId(namespaceIndex, new Guid("0bc7f946e67b6a84953be1acef444d73"));
        public static readonly NodeId Chat = new NodeId(namespaceIndex, new Guid("84685b52c936c7eef16f6b6feb669e6e"));
        public static readonly NodeId LoginType = new NodeId(namespaceIndex, new Guid("02c78620a9033208b8f9dc67c066ec8e"));
        public static readonly NodeId LoginChangePasswordForm = new NodeId(namespaceIndex, new Guid("0a624fb30ab0529af358b18c5dc98ebd"));
        public static readonly NodeId DigitalAlarmWithPushNotification1 = new NodeId(namespaceIndex, new Guid("84d5654663b4c4841535cc8dd58e04d2"));
        public static readonly NodeId LoginForm = new NodeId(namespaceIndex, new Guid("7fad017c7ed15bd1bcd3c98f1a5f394d"));
        public static readonly NodeId TrendCard = new NodeId(namespaceIndex, new Guid("f4ebd05ff2ef41dec128307aa03f42aa"));
        public static readonly NodeId DataGridCard = new NodeId(namespaceIndex, new Guid("a6376e94e978edfa6f46a2c2aeb40636"));
        public static readonly NodeId LiveAlarmsCard = new NodeId(namespaceIndex, new Guid("e3fbcc66e4c7eb11179714e5cfffc2bb"));
        public static readonly NodeId HistoricalAlarmsCard = new NodeId(namespaceIndex, new Guid("6e0214ef3b61059055d3dbe2889ea789"));
        public static readonly NodeId Commands = new NodeId(namespaceIndex, new Guid("6794a4497d791d97fbf2259fae3f6295"));
        public static readonly NodeId MachineID = new NodeId(namespaceIndex, new Guid("ac5e327390a8040ddc82db80e47fdba6"));
        public static readonly NodeId Login = new NodeId(namespaceIndex, new Guid("31284327d16bdc3911602fcd74dafc3f"));
        public static readonly NodeId LoginPasswordExpiredDialog = new NodeId(namespaceIndex, new Guid("5d200fe446986c2e64db3353bc97331f"));
        public static readonly NodeId Logout = new NodeId(namespaceIndex, new Guid("4f3c0f044d478e1c15e8d9d85939f613"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("OvenDemo_EmbeddedComputeModule");
    }
}
