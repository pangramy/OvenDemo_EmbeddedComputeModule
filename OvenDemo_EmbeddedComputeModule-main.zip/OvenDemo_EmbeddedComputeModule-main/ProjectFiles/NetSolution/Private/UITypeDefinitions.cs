using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "81f873c2df7d55065426b9107a80596d")]
public class MainPage : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "b247cebf619a6438c19940eeb806f899")]
public class Phases : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "d61a6bb0da58d2f94820c04b18e7e801")]
public class MainWindow : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "4fb7f81b6dd60556c0470e584dbd90f7")]
public class BasePanel : FTOptix.UI.Rectangle
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "dbaca6e4b7cb6e4b797569c1ff8b8012")]
public class Oven : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "3fa35f7bdabe3c91aa0123039eb12153")]
public class MainWindowWeb : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "78704b78222ebe881a0e3108a1112211")]
public class Card : FTOptix.UI.Rectangle
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "3ecc89fdf8d4b26e5b5794659865e065")]
public class MainScaleLayout : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "f6596ab428a62b650eee16ccfd887090")]
public class Badge : FTOptix.UI.Button
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "1bc303e65dfecec71c9ff005ae61a312")]
public class SinglePhasePanel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "96ba3c9faea7d1a6f61c596b208b06fd")]
public class NotificationPopup : FTOptix.UI.Popup
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "e9acad2f27612c7fa5b0859b6535933b")]
public class Recipes : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "37de321274886ab9e562997a9966ca18")]
public class MainViewData : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "4635f89fd25982d930145d5d90b2d433")]
public class MainViewAlarms : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "0bc7f946e67b6a84953be1acef444d73")]
public class MainViewSettings : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "84685b52c936c7eef16f6b6feb669e6e")]
public class Chat : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "02c78620a9033208b8f9dc67c066ec8e")]
public class LoginType : FTOptix.UI.Popup
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "0a624fb30ab0529af358b18c5dc98ebd")]
public class LoginChangePasswordForm : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "7fad017c7ed15bd1bcd3c98f1a5f394d")]
public class LoginForm : FTOptix.UI.PanelLoader
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "f4ebd05ff2ef41dec128307aa03f42aa")]
public class TrendCard : Card
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "a6376e94e978edfa6f46a2c2aeb40636")]
public class DataGridCard : Card
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "e3fbcc66e4c7eb11179714e5cfffc2bb")]
public class LiveAlarmsCard : Card
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "6e0214ef3b61059055d3dbe2889ea789")]
public class HistoricalAlarmsCard : Card
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "6794a4497d791d97fbf2259fae3f6295")]
public class Commands : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "ac5e327390a8040ddc82db80e47fdba6")]
public class MachineID : BasePanel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "31284327d16bdc3911602fcd74dafc3f")]
public class Login : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "5d200fe446986c2e64db3353bc97331f")]
public class LoginPasswordExpiredDialog : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "4f3c0f044d478e1c15e8d9d85939f613")]
public class Logout : FTOptix.UI.Panel
{
}
