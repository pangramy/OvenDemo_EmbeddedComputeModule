using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "OvenDemo_EmbeddedComputeModule", Guid = "84d5654663b4c4841535cc8dd58e04d2")]
public class DigitalAlarmWithPushNotification1 : FTOptix.Alarm.DigitalAlarm
{
#region Children properties
    //-------------------------------------------
    // WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
    //-------------------------------------------
    public FTOptix.NetLogic.NetLogicObject DigitalAlarmWithPushNotificationLogic
    {
        get
        {
            return (FTOptix.NetLogic.NetLogicObject)Refs.GetObject("DigitalAlarmWithPushNotificationLogic");
        }
    }
    public UAManagedCore.NodeId EmailUser
    {
        get
        {
            return (UAManagedCore.NodeId)Refs.GetVariable("EmailUser").Value.Value;
        }
        set
        {
            Refs.GetVariable("EmailUser").SetValue(value);
        }
    }
    public FTOptix.Core.NodePointer EmailUserVariable
    {
        get
        {
            return (FTOptix.Core.NodePointer)Refs.GetVariable("EmailUser");
        }
    }
    public UAManagedCore.NodeId EmailSender
    {
        get
        {
            return (UAManagedCore.NodeId)Refs.GetVariable("EmailSender").Value.Value;
        }
        set
        {
            Refs.GetVariable("EmailSender").SetValue(value);
        }
    }
    public FTOptix.Core.NodePointer EmailSenderVariable
    {
        get
        {
            return (FTOptix.Core.NodePointer)Refs.GetVariable("EmailSender");
        }
    }
#endregion
}
